# Changelog for snake-haskell

## Unreleased changes
